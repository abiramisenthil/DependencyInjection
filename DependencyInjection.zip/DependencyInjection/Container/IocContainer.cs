﻿using Unity;
using Unity.Injection;

namespace DependencyInjection.Container
{
    public class IocContainer
    {
        public static void ContainerConfiguration()
        {

            IUnityContainer fulfillmentContainer = new UnityContainer();
            fulfillmentContainer.RegisterType<ICabinet, BaseCabinet>("ForKitchen");
            fulfillmentContainer.RegisterType<ICabinet, WallCabinet>();

            fulfillmentContainer.RegisterType<CabinetMaker>("ForKitchenNext",
                new InjectionConstructor(fulfillmentContainer.Resolve<ICabinet>("ForKitchen")));

        }
    }
}
