﻿namespace DependencyInjection
{
    public class CabinetMaker
    {
        private ICabinet _cabinetModel;
        public string CabinetType { get; set; }

        public CabinetMaker(ICabinet cabinetModel)
        {
            _cabinetModel = cabinetModel;
        }

        public void CabinetBuilder()
        {
            _cabinetModel.MakeCabinet();
        }
    }
}
