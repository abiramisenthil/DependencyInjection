﻿using System;
using Unity;
using Unity.Injection;

namespace DependencyInjection
{
    class Program
    {
        static void Main(string[] args)
        {
            IUnityContainer fulfillmentDesk = new UnityContainer();
            fulfillmentDesk.RegisterType<ICabinet, KitchenCabinet>("ForKitchen");
            fulfillmentDesk.RegisterType<ICabinet, WallCabinet>();
            fulfillmentDesk.RegisterType<ITypeTwoScrews, TypeTwoScrews>();

            fulfillmentDesk.RegisterType<CabinetMaker>("ForKitchenNext",
                new InjectionConstructor(fulfillmentDesk.Resolve<ICabinet>("ForKitchen")));

            CabinetMaker maker1 = fulfillmentDesk.Resolve<CabinetMaker>();

            CabinetMaker maker2 = fulfillmentDesk.Resolve<CabinetMaker>("ForKitchenNext");
            maker2.CabinetBuilder();

            Console.ReadLine();
        }
    }
}
