﻿using System;

namespace DependencyInjection
{
    public class TypeTwoScrews : ITypeTwoScrews
    {
        public void GetTypeTwoScrews()
        {
            Console.WriteLine("Type two screws are ready to make Kitchen cabinet");
        }
    }
}
