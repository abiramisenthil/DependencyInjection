﻿using System;

namespace DependencyInjection
{
    public class KitchenCabinet : ICabinet
    {
        private ITypeTwoScrews _typeTwoScrews;

        public KitchenCabinet(ITypeTwoScrews typeTwoScrews)
        {
            _typeTwoScrews = typeTwoScrews;
        }
        public void MakeCabinet()
        {
            _typeTwoScrews.GetTypeTwoScrews();
            Console.WriteLine("Base cabinet has been build for your kitchen using Type Two Screws");
        }
    }
}
