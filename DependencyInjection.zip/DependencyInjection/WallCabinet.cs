﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DependencyInjection
{
    public class WallCabinet : ICabinet
    {
        public void MakeCabinet()
        {
            Console.WriteLine("Wall cabinet has been build for your Study Room");
        }
    }
}
